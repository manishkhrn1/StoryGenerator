"""This is a Hello World Program"""
print('Hello Programing World')
print('Programming Principles with Python')

#The following line prints the Course Code
print('#prog10004')