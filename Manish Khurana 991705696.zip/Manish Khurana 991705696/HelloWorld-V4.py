def sayHello() :
    helloMsg = 'Hello programming world'
    print(helloMsg)
    couseMsg = 'Programming Principles with Python'
    print(couseMsg)
    courseNo= 10004
    print('#prog' , courseNo , sep="")

sayHello()
