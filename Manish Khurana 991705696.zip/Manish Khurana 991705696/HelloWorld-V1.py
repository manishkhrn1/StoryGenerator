print('Hello Programming World')
print('Programming Principles with Python')
print('#prog10004')