import HelloModule                    

msg = HelloModule.HelloMessage()
msg.show()
